# CoreDNS

## MIGRATION NOTICE

This chart was moved its new location here: https://github.com/coredns/helm
