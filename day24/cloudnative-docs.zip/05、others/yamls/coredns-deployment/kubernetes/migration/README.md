# K8s/CoreDNS Corefile Migration

Corefile Migration has moved to https://github.com/coredns/corefile-migration/tree/master/migration